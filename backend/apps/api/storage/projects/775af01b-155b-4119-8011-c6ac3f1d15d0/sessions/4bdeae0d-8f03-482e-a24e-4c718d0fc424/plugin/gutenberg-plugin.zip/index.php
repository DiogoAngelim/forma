<?php
/**
 * Plugin Name: Forma Gutenberg Blocks
 * Description: Forma generated Gutenberg block collection.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
  exit;
}

require_once __DIR__ . '/01-index/index.php';
require_once __DIR__ . '/02-index/index.php';
