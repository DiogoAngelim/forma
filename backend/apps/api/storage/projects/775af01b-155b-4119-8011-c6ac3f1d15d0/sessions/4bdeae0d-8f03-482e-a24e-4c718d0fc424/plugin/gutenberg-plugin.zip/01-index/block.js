(function (blocks, element) {
  var el = element.createElement;
  var RawHTML = element.RawHTML;
  var markup = "<header class=\"wp-block-template-part\">\n\n    </header>";

  blocks.registerBlockType("wp/index", {
    title: "Index 1: Header",
    icon: 'layout',
    category: 'design',
    edit: function () {
      return el(RawHTML, null, markup);
    },
    save: function () {
      return el(RawHTML, null, markup);
    }
  });
})(window.wp.blocks, window.wp.element);
