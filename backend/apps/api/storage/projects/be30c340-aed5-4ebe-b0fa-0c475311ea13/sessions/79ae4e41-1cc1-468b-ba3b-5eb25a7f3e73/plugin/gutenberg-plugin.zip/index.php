<?php
/**
 * Plugin Name: Forma Gutenberg Blocks
 * Description: Forma generated Gutenberg block collection.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
  exit;
}

require_once __DIR__ . '/01-card-with-background-image/index.php';
require_once __DIR__ . '/02-dark-with-illustration/index.php';
require_once __DIR__ . '/03-hero-simple-centered/index.php';
