(function (blocks, element) {
  var el = element.createElement;
  var RawHTML = element.RawHTML;

  var markup1 = "<nav class=\"relative flex items-center justify-between sm:h-10 md:justify-center\" aria-label=\"Global\">\n          <div class=\"flex items-center flex-1 md:absolute md:inset-y-0 md:left-0\">\n            <div class=\"flex items-center justify-between w-full md:w-auto\">\n              <a href=\"#\">\n                <span class=\"sr-only\">Workflow</span>\n                <img class=\"h-8 w-auto sm:h-10\" src=\"img/\nlogos/workflow-mark-fuchsia-600.svg\" alt=\"Alt\">\n              </a>\n              <div class=\"-mr-2 flex items-center md:hidden\">\n                <button type=\"button\"\n                  class=\"bg-gray-50 rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-fuchsia-500\"\n                  aria-expanded=\"false\">\n                  <span class=\"sr-only\">Open main menu</span>\n                  <!-- Heroicon name: outline/menu -->\n                  <svg class=\"h-6 w-6\" xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" viewBox=\"0 0 24 24\"\n                    stroke=\"currentColor\" aria-hidden=\"true\">\n                    <path stroke-linecap=\"round\" stroke-linejoin=\"round\" stroke-width=\"2\" d=\"M4 6h16M4 12h16M4 18h16\" />\n                  </svg>\n                </button>\n              </div>\n            </div>\n          </div>\n          <div class=\"hidden md:flex md:space-x-10\">\n            <a href=\"#\" class=\"font-medium text-gray-500 hover:text-gray-900\">Product</a>\n\n            <a href=\"#\" class=\"font-medium text-gray-500 hover:text-gray-900\">Features</a>\n\n            <a href=\"#\" class=\"font-medium text-gray-500 hover:text-gray-900\">Marketplace</a>\n\n            <a href=\"#\" class=\"font-medium text-gray-500 hover:text-gray-900\">Company</a>\n          </div>\n          <div class=\"hidden md:absolute md:flex md:items-center md:justify-end md:inset-y-0 md:right-0\">\n            <span class=\"inline-flex rounded-md shadow\">\n              <a href=\"#\"\n                class=\"inline-flex items-center px-4 py-2 border border-transparent text-base font-medium rounded-md text-fuchsia-600 bg-white hover:bg-gray-50\">\n                Log in </a>\n            </span>\n          </div>\n        </nav>";

  blocks.registerBlockType("wp/herosimplecentered-herosimplecentered1global", {
    title: "Hero Simple Centered 1: Global",
    icon: 'layout',
    category: 'design',
    edit: function () {
      return el(RawHTML, null, markup1);
    },
    save: function () {
      return el(RawHTML, null, markup1);
    }
  });

  var markup2 = "<main class=\"mt-16 mx-auto max-w-7xl px-4 sm:mt-24\">\n      <div class=\"text-center\">\n        <h1 class=\"text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl\">\n          <span class=\"block xl:inline\">Data to enhance your</span>\n          <span class=\"block text-fuchsia-600 xl:inline\">online business</span>\n        </h1>\n        <p class=\"mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl\">Anim aute id\n          magna aliqua ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo. Elit sunt amet fugiat veniam\n          occaecat fugiat aliqua.</p>\n        <div class=\"mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8 gap-3\">\n          <div class=\"rounded-md shadow\">\n            <a href=\"#\"\n              class=\"inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-fuchsia-600 hover:bg-fuchsia-700 md:py-4 md:text-lg md:px-10\">\n              Get started </a>\n          </div>\n          <div class=\"rounded-md shadow sm:mt-0\">\n            <a href=\"#\"\n              class=\"inline-flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-fuchsia-600 bg-white hover:bg-gray-50 md:py-4 md:text-lg md:px-10\">\n              Live demo </a>\n          </div>\n        </div>\n      </div>\n    </main>";

  blocks.registerBlockType("wp/herosimplecentered-herosimplecentered2datatoenhanceyour", {
    title: "Hero Simple Centered 2: Data To Enhance Your Online Business",
    icon: 'layout',
    category: 'design',
    edit: function () {
      return el(RawHTML, null, markup2);
    },
    save: function () {
      return el(RawHTML, null, markup2);
    }
  });
})(window.wp.blocks, window.wp.element);
