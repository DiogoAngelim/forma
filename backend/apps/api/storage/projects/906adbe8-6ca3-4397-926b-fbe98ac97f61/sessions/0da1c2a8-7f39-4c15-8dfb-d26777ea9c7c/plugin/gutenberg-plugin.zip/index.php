<?php
/**
 * Plugin Name: Forma Gutenberg Blocks
 * Description: Forma generated Gutenberg block collection.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
  exit;
}

require_once __DIR__ . '/01-card-with-background-image/index.php';
require_once __DIR__ . '/02-dark-with-illustration/index.php';
require_once __DIR__ . '/03-hero-simple-centered/index.php';
require_once __DIR__ . '/04-hero-split-with-image/index.php';
require_once __DIR__ . '/05-hero-with-image-tiles/index.php';
require_once __DIR__ . '/06-index/index.php';
require_once __DIR__ . '/07-simple-centered-with-background-image/index.php';
