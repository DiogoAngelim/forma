import React from 'react';

export default function Block1(props) {
  return (
    <div>

<div className="bg-white">
  <header>
    <div className="relative bg-white my-block">
      <div
        className="flex justify-between items-center max-w-7xl mx-auto px-4 py-6 sm:px-6 md:justify-start md:space-x-10 lg:px-8">
        
        <div className="flex justify-start lg:w-0 lg:flex-1">
          <a href="#">
            <span className="sr-only">Workflow</span>
            <img className="h-8 w-auto sm:h-10" src="http://localhost/mark.svg" alt="Alt">
          </a>
        </div>

        
        <div className="-mr-2 -my-2 md:hidden">
          <button type="button"
            className="toggle-mobile-menu bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100">
            <span className="sr-only">Open menu</span>
            
            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="#4B5563">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        
        <nav className="hidden md:flex space-x-10">
          
          <div className="relative">
            <button type="button"
              className="toggle-solutions text-gray-500 group bg-white rounded-md inline-flex items-center text-base font-medium hover:text-gray-900">
              <span>Solutions</span>
              <svg className="text-gray-400 ml-2 h-5 w-5 group-hover:text-gray-500" fill="#9CA3AF" viewBox="0 0 20 20">
                <path fill-rule="evenodd"
                  d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                  clip-rule="evenodd" />
              </svg>
            </button>

            
            <div
              className="solutions-menu hidden absolute z-10 -ml-4 mt-3 transform w-screen max-w-md lg:max-w-2xl lg:ml-0 lg:left-1/2 lg:-translate-x-1/2">
              <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 overflow-hidden">
                <div className="relative grid gap-6 bg-white px-5 py-6 sm:gap-8 sm:p-8 lg:grid-cols-2">
                  <a href="#" className="-m-3 p-3 flex items-start rounded-lg hover:bg-gray-50">
                    <div
                      className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-md bg-fuchsia-600 text-white">
                      <svg className="h-6 w-6" stroke="#FFF" fill="none" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                          d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                      </svg>
                    </div>
                    <div className="ml-4">
                      <p className="text-base font-medium text-gray-900">Inbox</p>
                      <p className="mt-1 text-sm text-gray-500">Get your messages in one place.</p>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <a href="#" className="text-base font-medium text-gray-500 hover:text-gray-900">Pricing</a>
          <a href="#" className="text-base font-medium text-gray-500 hover:text-gray-900">Partners</a>
          <a href="#" className="text-base font-medium text-gray-500 hover:text-gray-900">Company</a>
        </nav>

        
        <div className="hidden md:flex items-center justify-end md:flex-1 lg:w-0">
          <a href="#" className="text-base font-medium text-gray-500 hover:text-gray-900">Sign in</a>
          <a href="#"
            className="ml-8 px-4 py-2 rounded-md text-base font-medium text-white bg-fuchsia-600 hover:bg-fuchsia-700">Sign
            up</a>
        </div>
      </div>

      
      <div className="mobile-menu hidden absolute z-30 top-0 inset-x-0 p-2 transition transform origin-top-right">
        <div className="rounded-lg shadow-lg ring-1 ring-black ring-opacity-5 bg-white divide-y-2 divide-gray-50">
          <div className="pt-5 pb-6 px-5">
            <div className="flex items-center justify-between">
              <div>
                <img className="h-8 w-auto" src="http://localhost/mark.svg" alt="Workflow">
              </div>
              <div className="-mr-2">
                <button type="button"
                  className="close-mobile-menu bg-white rounded-md p-2 inline-flex items-center justify-center text-gray-400 hover:text-gray-500 hover:bg-gray-100">
                  <span className="sr-only">Close menu</span>
                  
                  <svg className="h-6 w-6" stroke="#4B5563" fill="none" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="mt-6">
              <nav className="grid gap-y-8">
                <a href="#" className="text-base font-medium text-gray-900 hover:text-gray-700">Solutions</a>
                <a href="#" className="text-base font-medium text-gray-900 hover:text-gray-700">Pricing</a>
                <a href="#" className="text-base font-medium text-gray-900 hover:text-gray-700">Partners</a>
                <a href="#" className="text-base font-medium text-gray-900 hover:text-gray-700">Company</a>
              </nav>
            </div>
          </div>
          <div className="py-6 px-5 space-y-6">
            <div>
              <a href="#"
                className="w-full flex items-center justify-center px-4 py-2 rounded-md text-base font-medium text-white bg-fuchsia-600 hover:bg-fuchsia-700">Sign
                up</a>
              <p className="mt-6 text-center text-base font-medium text-gray-500">
                Existing customer?
                <a href="#" className="text-fuchsia-600 hover:text-fuchsia-500">Sign in</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>

  <main>
    <div>
      
      <div className="relative">
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gray-100"></div>
        <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div className="relative shadow-xl sm:rounded-2xl sm:overflow-hidden">
            <div className="absolute inset-0">
              <img className="h-full w-full object-cover"
                src="https://images.unsplash.com/photo-1521737852567-6949f3f9f2b5?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=2830&q=80&sat=-100"
                alt="People working on laptops">
              <div className="absolute inset-0 bg-fuchsia-700 mix-blend-multiply"></div>
            </div>
            <div className="relative px-4 py-16 sm:px-6 sm:py-24 lg:py-32 lg:px-8">
              <h1 className="text-center text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl">
                <span className="block text-white">Take control of your</span>
                <span className="block text-fuchsia-200">customer support</span>
              </h1>
              <p className="mt-6 max-w-lg mx-auto text-center text-xl text-fuchsia-200 sm:max-w-3xl">Anim aute id magna
                aliqua
                ad ad non deserunt sunt. Qui irure qui lorem cupidatat commodo. Elit sunt amet fugiat veniam occaecat
                fugiat aliqua.</p>
              <div className="mt-10 max-w-sm mx-auto sm:max-w-none sm:flex sm:justify-center">
                <div className="space-y-4 sm:space-y-0 sm:mx-auto sm:inline-grid sm:grid-cols-2 sm:gap-5">
                  <a href="#"
                    className="flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-fuchsia-700 bg-white hover:bg-fuchsia-50 sm:px-8">
                    Get started </a>
                  <a href="#"
                    className="flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-fuchsia-500 bg-opacity-60 hover:bg-opacity-70 sm:px-8">
                    Live demo </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      
      <div className="bg-gray-100">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm font-semibold uppercase text-gray-500 tracking-wide">Trusted by over 5 very
            average small businesses</p>
          <div className="mt-6 grid grid-cols-2 gap-8 md:grid-cols-6 lg:grid-cols-5">
            <div className="col-span-1 flex justify-center md:col-span-2 lg:col-span-1">
              <img className="h-12" src="img/logos/tuple-logo-gray-900.svg" alt="Tuple">
            </div>
            <div className="col-span-1 flex justify-center md:col-span-2 lg:col-span-1">
              <img className="h-12" src="img/logos/savvycal-logo-gray-900.svg" alt="Mirage">
            </div>
            <div className="col-span-1 flex justify-center md:col-span-2 lg:col-span-1">
              <img className="h-12" src="img/logos/statamic-logo-gray-900.svg" alt="StaticKit">
            </div>
            <div className="col-span-1 flex justify-center md:col-span-2 md:col-start-2 lg:col-span-1">
              <img className="h-12" src="img/logos/transistor-logo-gray-900.svg" alt="Transistor">
            </div>
            <div className="col-span-2 flex justify-center md:col-span-2 md:col-start-4 lg:col-span-1">
              <img className="h-12" src="img/logos/reform-logo-gray-900.svg" alt="Reform">
            </div>
          </div>
        </div>
      </div>
    </div>

    
  </main>
</div>
</div>
  );
}
