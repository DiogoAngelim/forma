import React from 'react';

export default function Block5(props) {
  return (
    <div>
<style>
  /*! tailwindcss v4.1.8 | MIT License | https://tailwindcss.com */
  @layer properties {
    @supports (((-webkit-hyphens:none)) and (not (margin-trim:inline))) or ((-moz-orient:inline) and (not (color:rgb(from red r g b)))) {

      *,
      :before,
      :after,
      ::backdrop {
        --tw-space-y-reverse: 0;
        --tw-divide-y-reverse: 0;
        --tw-border-style: solid;
        --tw-gradient-position: initial;
        --tw-gradient-from: #0000;
        --tw-gradient-via: #0000;
        --tw-gradient-to: #0000;
        --tw-gradient-stops: initial;
        --tw-gradient-via-stops: initial;
        --tw-gradient-from-position: 0%;
        --tw-gradient-via-position: 50%;
        --tw-gradient-to-position: 100%;
        --tw-font-weight: initial;
        --tw-tracking: initial;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-color: initial;
        --tw-shadow-alpha: 100%;
        --tw-inset-shadow: 0 0 #0000;
        --tw-inset-shadow-color: initial;
        --tw-inset-shadow-alpha: 100%;
        --tw-ring-color: initial;
        --tw-ring-shadow: 0 0 #0000;
        --tw-inset-ring-color: initial;
        --tw-inset-ring-shadow: 0 0 #0000;
        --tw-ring-inset: initial;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-blur: initial;
        --tw-brightness: initial;
        --tw-contrast: initial;
        --tw-grayscale: initial;
        --tw-hue-rotate: initial;
        --tw-invert: initial;
        --tw-opacity: initial;
        --tw-saturate: initial;
        --tw-sepia: initial;
        --tw-drop-shadow: initial;
        --tw-drop-shadow-color: initial;
        --tw-drop-shadow-alpha: 100%;
        --tw-drop-shadow-size: initial;
        --tw-outline-style: solid
      }
    }
  }

  @layer theme {

    :root,
    :host {
      --font-sans: InterVariable, system-ui, sans-serif;
      --font-sans--font-feature-settings: "cv02", "cv03", "cv04", "cv11"
    }
  }

  @layer base {

    *,
    :after,
    :before,
    ::backdrop {
      box-sizing: border-box;
      border: 0 solid;
      margin: 0;
      padding: 0
    }

    ::file-selector-button {
      box-sizing: border-box;
      border: 0 solid;
      margin: 0;
      padding: 0
    }

    html,
    :host {
      -webkit-text-size-adjust: 100%;
      tab-size: 4;
      line-height: 1.5;
      font-family: var(--font-sans, ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji");
      font-feature-settings: var(--font-sans--font-feature-settings);
      font-variation-settings: initial;
      -webkit-tap-highlight-color: transparent
    }

    hr {
      height: 0;
      color: inherit;
      border-top-width: 1px
    }

    abbr:where([title]) {
      -webkit-text-decoration: underline dotted;
      text-decoration: underline dotted
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      font-size: inherit;
      font-weight: inherit
    }

    a {
      color: inherit;
      -webkit-text-decoration: inherit;
      -webkit-text-decoration: inherit;
      -webkit-text-decoration: inherit;
      text-decoration: inherit
    }

    b,
    strong {
      font-weight: bolder
    }

    code,
    kbd,
    samp,
    pre {
      font-feature-settings: initial;
      font-variation-settings: initial;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace;
      font-size: 1em
    }

    small {
      font-size: 80%
    }

    sub,
    sup {
      vertical-align: baseline;
      font-size: 75%;
      line-height: 0;
      position: relative
    }

    sub {
      bottom: -.25em
    }

    sup {
      top: -.5em
    }

    table {
      text-indent: 0;
      border-color: inherit;
      border-collapse: collapse
    }

    :-moz-focusring {
      outline: auto
    }

    progress {
      vertical-align: baseline
    }

    summary {
      display: list-item
    }

    ol,
    ul,
    menu {
      list-style: none
    }

    img,
    svg,
    video,
    canvas,
    audio,
    iframe,
    embed,
    object {
      vertical-align: middle;
      display: block
    }

    img,
    video {
      max-width: 100%;
      height: auto
    }

    button,
    input,
    select,
    optgroup,
    textarea {
      font: inherit;
      font-feature-settings: inherit;
      font-variation-settings: inherit;
      letter-spacing: inherit;
      color: inherit;
      opacity: 1;
      background-color: #0000;
      border-radius: 0
    }

    ::file-selector-button {
      font: inherit;
      font-feature-settings: inherit;
      font-variation-settings: inherit;
      letter-spacing: inherit;
      color: inherit;
      opacity: 1;
      background-color: #0000;
      border-radius: 0
    }

    :where(select:is([multiple], [size])) optgroup {
      font-weight: bolder
    }

    :where(select:is([multiple], [size])) optgroup option {
      padding-inline-start: 20px
    }

    ::file-selector-button {
      margin-inline-end: 4px
    }

    ::placeholder {
      opacity: 1
    }

    @supports (not ((-webkit-appearance:-apple-pay-button))) or (contain-intrinsic-size:1px) {
      ::placeholder {
        color: currentColor
      }

      @supports (color:color-mix(in lab, red, red)) {
        ::placeholder {
          color: color-mix(in oklab, currentcolor 50%, transparent)
        }
      }
    }

    textarea {
      resize: vertical
    }

    ::-webkit-search-decoration {
      -webkit-appearance: none
    }

    ::-webkit-date-and-time-value {
      min-height: 1lh;
      text-align: inherit
    }

    ::-webkit-datetime-edit {
      display: inline-flex
    }

    ::-webkit-datetime-edit-fields-wrapper {
      padding: 0
    }

    ::-webkit-datetime-edit {
      padding-block: 0
    }

    ::-webkit-datetime-edit-year-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-month-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-day-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-hour-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-minute-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-second-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-millisecond-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-meridiem-field {
      padding-block: 0
    }

    :-moz-ui-invalid {
      box-shadow: none
    }

    button,
    input:where([type=button], [type=reset], [type=submit]) {
      appearance: button
    }

    ::file-selector-button {
      appearance: button
    }

    ::-webkit-inner-spin-button {
      height: auto
    }

    ::-webkit-outer-spin-button {
      height: auto
    }

    [hidden]:where(:not([hidden=until-found])) {
      display: none !important
    }
  }

  @layer components;

  @layer utilities {
    .aepg {
      pointer-events: none
    }

    .aeph {
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border-width: 0;
      width: 1px;
      height: 1px;
      margin: -1px;
      padding: 0;
      position: absolute;
      overflow: hidden
    }

    .aepi {
      position: absolute
    }

    .aepj {
      position: fixed
    }

    .aepk {
      position: relative
    }

    .aepl {
      inset: 0
    }

    .aepm {
      inset-inline: 0
    }

    .aepn {
      inset-block: 0
    }

    .aepo {
      top: 0
    }

    .aepp {
      right: 0
    }

    .aepq {
      left: 50%
    }

    .aepr {
      isolation: isolate
    }

    .aeps {
      z-index: calc(10*-1)
    }

    .aept {
      z-index: 50
    }

    .aepu {
      margin: -.375rem
    }

    .aepv {
      margin: -.625rem
    }

    .aepw {
      margin-inline: -.75rem
    }

    .aepx {
      margin-inline: auto
    }

    .aepy {
      margin-block: -1.5rem
    }

    .aepz {
      margin-top: 1.5rem
    }

    .aeqa {
      margin-top: 2rem
    }

    .aeqb {
      margin-top: 2.5rem
    }

    .aeqc {
      margin-top: 3.5rem
    }

    .aeqd {
      margin-right: auto
    }

    .aeqe {
      margin-left: -6rem
    }

    .aeqf {
      margin-left: auto
    }

    .aeqg {
      display: block
    }

    .aeqh {
      display: flex
    }

    .aeqi {
      display: flow-root
    }

    .aeqj {
      display: none
    }

    .aeqk {
      display: inline-flex
    }

    .aeql {
      aspect-ratio: 2/3
    }

    .aeqm {
      aspect-ratio: 801/1036
    }

    .aeqn {
      width: 1.5rem;
      height: 1.5rem
    }

    .aeqo {
      height: 2rem
    }

    .aeqp {
      height: 64rem
    }

    .aeqq {
      width: 11rem
    }

    .aeqr {
      width: 50.0625rem
    }

    .aeqs {
      width: auto
    }

    .aeqt {
      width: 100%
    }

    .aequ {
      max-width: 42rem
    }

    .aeqv {
      max-width: 80rem
    }

    .aeqw {
      flex: none
    }

    .aeqx {
      transform: translateZ(0)var(--tw-rotate-x, )var(--tw-rotate-y, )var(--tw-rotate-z, )var(--tw-skew-x, )var(--tw-skew-y, )
    }

    .aeqy {
      align-items: center
    }

    .aeqz {
      justify-content: space-between
    }

    .aera {
      justify-content: center
    }

    .aerb {
      justify-content: flex-end
    }

    .aerc {
      gap: 2rem
    }

    :where(.aerd>:not(:last-child)) {
      --tw-space-y-reverse: 0;
      margin-block-start: calc(calc(.25rem*2)*var(--tw-space-y-reverse));
      margin-block-end: calc(calc(.25rem*2)*calc(1 - var(--tw-space-y-reverse)))
    }

    :where(.aere>:not(:last-child)) {
      --tw-space-y-reverse: 0;
      margin-block-start: calc(calc(.25rem*8)*var(--tw-space-y-reverse));
      margin-block-end: calc(calc(.25rem*8)*calc(1 - var(--tw-space-y-reverse)))
    }

    .aerf {
      column-gap: 1.5rem
    }

    .aerg {
      column-gap: 3.5rem
    }

    :where(.aerh>:not(:last-child)) {
      --tw-divide-y-reverse: 0;
      border-bottom-style: var(--tw-border-style);
      border-top-style: var(--tw-border-style);
      border-top-width: calc(1px*var(--tw-divide-y-reverse));
      border-bottom-width: calc(1px*calc(1 - var(--tw-divide-y-reverse)))
    }

    :where(.aeri>:not(:last-child)) {
      border-color: oklab(55.1% -.00265162 -.0268695/.1)
    }

    .aerj {
      overflow: hidden
    }

    .aerk {
      overflow: visible
    }

    .aerl {
      overflow-y: auto
    }

    .aerm {
      border-radius: .5rem
    }

    .aern {
      border-radius: .375rem
    }

    .aero {
      border-radius: .75rem
    }

    .aerp {
      background-color: oklab(21% -.00316127 -.0338527/.05)
    }

    .aerq {
      background-color: #c800de
    }

    .aerr {
      background-color: #fff
    }

    .aers {
      --tw-gradient-position: to top right
    }

    @supports (background-image:linear-gradient(in lab, red, red)) {
      .aers {
        --tw-gradient-position: to top right in oklab
      }
    }

    .aers {
      background-image: linear-gradient(var(--tw-gradient-stops))
    }

    .aert {
      --tw-gradient-from: #ff80b5;
      --tw-gradient-stops: var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from)var(--tw-gradient-from-position), var(--tw-gradient-to)var(--tw-gradient-to-position))
    }

    .aeru {
      --tw-gradient-to: #9089fc;
      --tw-gradient-stops: var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from)var(--tw-gradient-from-position), var(--tw-gradient-to)var(--tw-gradient-to-position))
    }

    .aerv {
      -webkit-mask-image: radial-gradient(32rem 32rem, #fff, #0000);
      mask-image: radial-gradient(32rem 32rem, #fff, #0000)
    }

    .aerw {
      fill: #f9fafb
    }

    .aerx {
      stroke: #e5e7eb
    }

    .aery {
      object-fit: cover
    }

    .aerz {
      padding: .375rem
    }

    .aesa {
      padding: .625rem
    }

    .aesb {
      padding: 1.5rem
    }

    .aesc {
      padding-inline: .75rem
    }

    .aesd {
      padding-inline: .875rem
    }

    .aese {
      padding-inline: 1.5rem
    }

    .aesf {
      padding-block: .5rem
    }

    .aesg {
      padding-block: .625rem
    }

    .aesh {
      padding-block: 1.5rem
    }

    .aesi {
      padding-top: 8rem
    }

    .aesj {
      padding-top: 9rem
    }

    .aesk {
      padding-bottom: 8rem
    }

    .aesl {
      font-size: 3rem;
      line-height: var(--tw-leading, 1)
    }

    .aesm {
      font-size: 1rem;
      line-height: 1.75rem
    }

    .aesn {
      font-size: 1.125rem;
      line-height: var(--tw-leading, calc(1.75/1.125))
    }

    .aeso {
      font-size: .875rem;
      line-height: var(--tw-leading, calc(1.25/.875))
    }

    .aesp {
      font-size: .875rem;
      line-height: 1.5rem
    }

    .aesq {
      --tw-font-weight: 500;
      font-weight: 500
    }

    .aesr {
      --tw-font-weight: 600;
      font-weight: 600
    }

    .aess {
      --tw-tracking: -.025em;
      letter-spacing: -.025em
    }

    .aest {
      text-wrap: pretty
    }

    .aesu {
      color: rgb(106, 114, 130)
    }

    .aesv {
      color: rgb(54, 65, 83)
    }

    .aesw {
      color: #101828
    }

    .aesx {
      color: #fff
    }

    .aesy {
      opacity: .3
    }

    .aesz {
      --tw-shadow: 0 10px 15px -3px var(--tw-shadow-color, #0000001a), 0 4px 6px -4px var(--tw-shadow-color, #0000001a);
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
    }

    .aeta {
      --tw-shadow: 0 1px 2px 0 var(--tw-shadow-color, #0000000d);
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
    }

    .aetb {
      --tw-ring-shadow: var(--tw-ring-inset, )0 0 0 calc(1px + var(--tw-ring-offset-width))var(--tw-ring-color, currentcolor);
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
    }

    .aetc {
      --tw-ring-color: oklab(21% -.00316127 -.0338527/.1)
    }

    .aetd {
      --tw-blur: blur(64px);
      filter: var(--tw-blur, )var(--tw-brightness, )var(--tw-contrast, )var(--tw-grayscale, )var(--tw-hue-rotate, )var(--tw-invert, )var(--tw-saturate, )var(--tw-sepia, )var(--tw-drop-shadow, )
    }

    .aete {
      --tw-ring-inset: inset
    }

    .aetf::backdrop {
      background-color: #0000
    }
  }
</style>
<div className="aerj">
  <div className="aerr">
    <header className="aepi aepm aepo aept">
      <nav aria-label="Global" className="aepx aeqh aeqv aeqy aeqz aesb aeun">
        <div className="aeqh aeui"><a href="#" className="aepu aerz"><span className="aeph">Your Company</span><img alt="Alt"
              src="https://tailwindcss.com/plus-assets/img/logos/mark.svg?color=indigo&amp;shade=600"
              className="aeqo aeqs"></a></div>
        <div className="aeqh aeuf"><button type="button" className="aepv aeqk aeqy aera aern aesa aesv"><span className="aeph">Open
              main menu</span><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5"
              stroke="currentColor" aria-hidden="true" data-slot="icon" className="aeqn">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5">
              </path>
            </svg></button></div>
        <div className="aeqj aeue aeum"><a href="#" className="aesp aesr aesw">Product</a><a href="#"
            className="aesp aesr aesw">Features</a><a href="#" className="aesp aesr aesw">Marketplace</a><a href="#"
            className="aesp aesr aesw">Company</a></div>
        <div className="aeqj aeue aeui aeul"><a href="#" className="aesp aesr aesw">Log in <span aria-hidden="true">→</span></a>
        </div>
      </nav>
    </header>
    <main>
      <div className="aepk aepr"><svg aria-hidden="true" className="aepi aepm aepo aeps aeqp aeqt aerv aerx">
          <defs>
            <pattern x="50%" y="-1" id="1f932ae7-37de-4c0a-a8b0-a6e3b4d44b84" width="200" height="200"
              patternUnits="userSpaceOnUse">
              <path d="M.5 200V.5H200" fill="none"></path>
            </pattern>
          </defs>
          <g x="50%" y="-1" className="aerk aerw">
            <path d="M-200 0h201v201h-201Z M600 0h201v201h-201Z M-400 600h201v201h-201Z M200 800h201v201h-201Z"
              strokeWidth="0"></path>
          </g>
          <rect fill="url(#1f932ae7-37de-4c0a-a8b0-a6e3b4d44b84)" width="100%" height="100%" strokeWidth="0"></rect>
        </svg>
        <div aria-hidden="true" className="aepi aepo aepp aepq aeps aeqe aeqx aerj aetd aeud aeus clip-path-parent">
          <div className="aeqm aeqr aers aert aeru aesy"
            style={{clipPath: "polygon(63.1% 29.5%, 100% 17.1%, 76.6% 3%, 48.4% 0%, 44.6% 4.7%, 54.5% 25.3%, 59.8% 49%, 55.2% 57.8%, 44.4% 57.2%, 27.8% 47.9%, 35.1% 81.5%, 0% 97.7%, 39.2% 100%, 35.2% 81.4%, 97.2% 52.8%, 63.1% 29.5%)"}}>
          </div>
        </div>
        <div className="aerj">
          <div className="aepx aeqv aese aesj aesk aett aeun aeuo">
            <div className="aepx aequ aerg aeub aeue aeug aeuk">
              <div className="aepk aeqt aeuh aeuj aeut">
                <h1 className="aesl aesr aess aest aesw aetw">We’re changing the way people connect</h1>
                <p className="aeqa aesn aesq aest aesu aeto aetx aeug">Anim aute id magna aliqua ad ad non deserunt sunt.
                  Qui irure qui lorem cupidatat commodo. Elit sunt amet fugiat veniam occaecat fugiat aliqua. Anim aute
                  id magna aliqua ad ad non deserunt sunt.</p>
                <div className="aeqb aeqh aeqy aerf"><a href="#"
                    className="aern aerq aesd aesg aeso aesr aesx aeta aeth aeti aetj aetk">Get started</a><a href="#"
                    className="aesp aesr aesw">Live demo <span aria-hidden="true">→</span></a></div>
              </div>
              <div className="aeqc aeqh aerb aerc aetl aetq aetv aeuc aeuq">
                <div className="aeqf aeqq aeqw aere aesi aetn aetu aeua aeup aeur aeuu">
                  <div className="aepk"><img alt="Alt"
                      src="https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;h=528&amp;q=80"
                      className="aeql aeqt aero aerp aery aesz">
                    <div className="aepg aepi aepl aero aetb aetc aete"></div>
                  </div>
                </div>
                <div className="aeqd aeqq aeqw aere aetm aets aeup">
                  <div className="aepk"><img alt="Alt"
                      src="https://images.unsplash.com/photo-1485217988980-11786ced9454?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;h=528&amp;q=80"
                      className="aeql aeqt aero aerp aery aesz">
                    <div className="aepg aepi aepl aero aetb aetc aete"></div>
                  </div>
                  <div className="aepk"><img alt="Alt"
                      src="https://images.unsplash.com/photo-1559136555-9303baea8ebd?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;crop=focalpoint&amp;fp-x=.4&amp;w=396&amp;h=528&amp;q=80"
                      className="aeql aeqt aero aerp aery aesz">
                    <div className="aepg aepi aepl aero aetb aetc aete"></div>
                  </div>
                </div>
                <div className="aeqq aeqw aere aesi aetr">
                  <div className="aepk"><img alt="Alt"
                      src="https://images.unsplash.com/photo-1670272504528-790c24957dda?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;crop=left&amp;w=400&amp;h=528&amp;q=80"
                      className="aeql aeqt aero aerp aery aesz">
                    <div className="aepg aepi aepl aero aetb aetc aete"></div>
                  </div>
                  <div className="aepk"><img alt="Alt"
                      src="https://images.unsplash.com/photo-1670272505284-8faba1c31f7d?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;h=528&amp;q=80"
                      className="aeql aeqt aero aerp aery aesz">
                    <div className="aepg aepi aepl aero aetb aetc aete"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>
</div>
  );
}
