import React from 'react';

export default function Block7(props) {
  return (
    <div>
<style>
  /*! tailwindcss v4.1.8 | MIT License | https://tailwindcss.com */
  @layer properties {
    @supports (((-webkit-hyphens:none)) and (not (margin-trim:inline))) or ((-moz-orient:inline) and (not (color:rgb(from red r g b)))) {

      *,
      :before,
      :after,
      ::backdrop {
        --tw-translate-x: 0;
        --tw-translate-y: 0;
        --tw-translate-z: 0;
        --tw-space-y-reverse: 0;
        --tw-divide-y-reverse: 0;
        --tw-border-style: solid;
        --tw-gradient-position: initial;
        --tw-gradient-from: #0000;
        --tw-gradient-via: #0000;
        --tw-gradient-to: #0000;
        --tw-gradient-stops: initial;
        --tw-gradient-via-stops: initial;
        --tw-gradient-from-position: 0%;
        --tw-gradient-via-position: 50%;
        --tw-gradient-to-position: 100%;
        --tw-font-weight: initial;
        --tw-tracking: initial;
        --tw-shadow: 0 0 #0000;
        --tw-shadow-color: initial;
        --tw-shadow-alpha: 100%;
        --tw-inset-shadow: 0 0 #0000;
        --tw-inset-shadow-color: initial;
        --tw-inset-shadow-alpha: 100%;
        --tw-ring-color: initial;
        --tw-ring-shadow: 0 0 #0000;
        --tw-inset-ring-color: initial;
        --tw-inset-ring-shadow: 0 0 #0000;
        --tw-ring-inset: initial;
        --tw-ring-offset-width: 0px;
        --tw-ring-offset-color: #fff;
        --tw-ring-offset-shadow: 0 0 #0000;
        --tw-blur: initial;
        --tw-brightness: initial;
        --tw-contrast: initial;
        --tw-grayscale: initial;
        --tw-hue-rotate: initial;
        --tw-invert: initial;
        --tw-opacity: initial;
        --tw-saturate: initial;
        --tw-sepia: initial;
        --tw-drop-shadow: initial;
        --tw-drop-shadow-color: initial;
        --tw-drop-shadow-alpha: 100%;
        --tw-drop-shadow-size: initial;
        --tw-outline-style: solid
      }
    }
  }

  @layer theme {

    :root,
    :host {
      --font-sans: InterVariable, system-ui, sans-serif;
      --font-sans--font-feature-settings: "cv02", "cv03", "cv04", "cv11"
    }
  }

  @layer base {

    *,
    :after,
    :before,
    ::backdrop {
      box-sizing: border-box;
      border: 0 solid;
      margin: 0;
      padding: 0
    }

    ::file-selector-button {
      box-sizing: border-box;
      border: 0 solid;
      margin: 0;
      padding: 0
    }

    html,
    :host {
      -webkit-text-size-adjust: 100%;
      tab-size: 4;
      line-height: 1.5;
      font-family: var(--font-sans, ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji");
      font-feature-settings: var(--font-sans--font-feature-settings);
      font-variation-settings: initial;
      -webkit-tap-highlight-color: transparent
    }

    hr {
      height: 0;
      color: inherit;
      border-top-width: 1px
    }

    abbr:where([title]) {
      -webkit-text-decoration: underline dotted;
      text-decoration: underline dotted
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    h6 {
      font-size: inherit;
      font-weight: inherit
    }

    a {
      color: inherit;
      -webkit-text-decoration: inherit;
      -webkit-text-decoration: inherit;
      -webkit-text-decoration: inherit;
      text-decoration: inherit
    }

    b,
    strong {
      font-weight: bolder
    }

    code,
    kbd,
    samp,
    pre {
      font-feature-settings: initial;
      font-variation-settings: initial;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, Liberation Mono, Courier New, monospace;
      font-size: 1em
    }

    small {
      font-size: 80%
    }

    sub,
    sup {
      vertical-align: baseline;
      font-size: 75%;
      line-height: 0;
      position: relative
    }

    sub {
      bottom: -.25em
    }

    sup {
      top: -.5em
    }

    table {
      text-indent: 0;
      border-color: inherit;
      border-collapse: collapse
    }

    :-moz-focusring {
      outline: auto
    }

    progress {
      vertical-align: baseline
    }

    summary {
      display: list-item
    }

    ol,
    ul,
    menu {
      list-style: none
    }

    img,
    svg,
    video,
    canvas,
    audio,
    iframe,
    embed,
    object {
      vertical-align: middle;
      display: block
    }

    img,
    video {
      max-width: 100%;
      height: auto
    }

    button,
    input,
    select,
    optgroup,
    textarea {
      font: inherit;
      font-feature-settings: inherit;
      font-variation-settings: inherit;
      letter-spacing: inherit;
      color: inherit;
      opacity: 1;
      background-color: #0000;
      border-radius: 0
    }

    ::file-selector-button {
      font: inherit;
      font-feature-settings: inherit;
      font-variation-settings: inherit;
      letter-spacing: inherit;
      color: inherit;
      opacity: 1;
      background-color: #0000;
      border-radius: 0
    }

    :where(select:is([multiple], [size])) optgroup {
      font-weight: bolder
    }

    :where(select:is([multiple], [size])) optgroup option {
      padding-inline-start: 20px
    }

    ::file-selector-button {
      margin-inline-end: 4px
    }

    ::placeholder {
      opacity: 1
    }

    @supports (not ((-webkit-appearance:-apple-pay-button))) or (contain-intrinsic-size:1px) {
      ::placeholder {
        color: currentColor
      }

      @supports (color:color-mix(in lab, red, red)) {
        ::placeholder {
          color: color-mix(in oklab, currentcolor 50%, transparent)
        }
      }
    }

    textarea {
      resize: vertical
    }

    ::-webkit-search-decoration {
      -webkit-appearance: none
    }

    ::-webkit-date-and-time-value {
      min-height: 1lh;
      text-align: inherit
    }

    ::-webkit-datetime-edit {
      display: inline-flex
    }

    ::-webkit-datetime-edit-fields-wrapper {
      padding: 0
    }

    ::-webkit-datetime-edit {
      padding-block: 0
    }

    ::-webkit-datetime-edit-year-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-month-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-day-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-hour-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-minute-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-second-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-millisecond-field {
      padding-block: 0
    }

    ::-webkit-datetime-edit-meridiem-field {
      padding-block: 0
    }

    :-moz-ui-invalid {
      box-shadow: none
    }

    button,
    input:where([type=button], [type=reset], [type=submit]) {
      appearance: button
    }

    ::file-selector-button {
      appearance: button
    }

    ::-webkit-inner-spin-button {
      height: auto
    }

    ::-webkit-outer-spin-button {
      height: auto
    }

    [hidden]:where(:not([hidden=until-found])) {
      display: none !important
    }
  }

  @layer components;

  @layer utilities {
    .abqm {
      clip: rect(0, 0, 0, 0);
      white-space: nowrap;
      border-width: 0;
      width: 1px;
      height: 1px;
      margin: -1px;
      padding: 0;
      position: absolute;
      overflow: hidden
    }

    .abqn {
      position: absolute
    }

    .abqo {
      position: fixed
    }

    .abqp {
      position: relative
    }

    .abqq {
      inset: 0
    }

    .abqr {
      inset-inline: 0
    }

    .abqs {
      inset-block: 0
    }

    .abqt {
      top: -10rem
    }

    .abqu {
      top: 0
    }

    .abqv {
      top: calc(100% - 13rem)
    }

    .abqw {
      right: 0
    }

    .abqx {
      left: calc(50% + 3rem)
    }

    .abqy {
      left: calc(50% - 11rem)
    }

    .abqz {
      isolation: isolate
    }

    .abra {
      z-index: calc(10*-1)
    }

    .abrb {
      z-index: 50
    }

    .abrc {
      margin: -.375rem
    }

    .abrd {
      margin: -.625rem
    }

    .abre {
      margin-inline: -.75rem
    }

    .abrf {
      margin-inline: auto
    }

    .abrg {
      margin-block: -1.5rem
    }

    .abrh {
      margin-top: 1.5rem
    }

    .abri {
      margin-top: 2rem
    }

    .abrj {
      margin-top: 2.5rem
    }

    .abrk {
      display: block
    }

    .abrl {
      display: flex
    }

    .abrm {
      display: flow-root
    }

    .abrn {
      display: none
    }

    .abro {
      display: inline-flex
    }

    .abrp {
      aspect-ratio: 1155/678
    }

    .abrq {
      width: 1.5rem;
      height: 1.5rem
    }

    .abrr {
      width: 100%;
      height: 100%
    }

    .abrs {
      height: 2rem
    }

    .abrt {
      width: 36.125rem
    }

    .abru {
      width: auto
    }

    .abrv {
      width: 100%
    }

    .abrw {
      max-width: 42rem
    }

    .abrx {
      max-width: 80rem
    }

    .abry {
      --tw-translate-x: calc(calc(1/2*100%)*-1);
      translate: var(--tw-translate-x)var(--tw-translate-y)
    }

    .abrz {
      rotate: 30deg
    }

    .absa {
      transform: translateZ(0)var(--tw-rotate-x, )var(--tw-rotate-y, )var(--tw-rotate-z, )var(--tw-skew-x, )var(--tw-skew-y, )
    }

    .absb {
      align-items: center
    }

    .absc {
      justify-content: space-between
    }

    .absd {
      justify-content: center
    }

    :where(.abse>:not(:last-child)) {
      --tw-space-y-reverse: 0;
      margin-block-start: calc(calc(.25rem*2)*var(--tw-space-y-reverse));
      margin-block-end: calc(calc(.25rem*2)*calc(1 - var(--tw-space-y-reverse)))
    }

    .absf {
      column-gap: 1.5rem
    }

    :where(.absg>:not(:last-child)) {
      --tw-divide-y-reverse: 0;
      border-bottom-style: var(--tw-border-style);
      border-top-style: var(--tw-border-style);
      border-top-width: calc(1px*var(--tw-divide-y-reverse));
      border-bottom-width: calc(1px*calc(1 - var(--tw-divide-y-reverse)))
    }

    :where(.absh>:not(:last-child)) {
      border-color: oklab(55.1% -.00265162 -.0268695/.25)
    }

    .absi {
      overflow: hidden
    }

    .absj {
      overflow-y: auto
    }

    .absk {
      border-radius: 3.40282e38px
    }

    .absl {
      border-radius: .5rem
    }

    .absm {
      border-radius: .375rem
    }

    .absn {
      background-color: #101828
    }

    .abso {
      background-color: #e12afb
    }

    .absp {
      --tw-gradient-position: to top right
    }

    @supports (background-image:linear-gradient(in lab, red, red)) {
      .absp {
        --tw-gradient-position: to top right in oklab
      }
    }

    .absp {
      background-image: linear-gradient(var(--tw-gradient-stops))
    }

    .absq {
      --tw-gradient-from: #ff80b5;
      --tw-gradient-stops: var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from)var(--tw-gradient-from-position), var(--tw-gradient-to)var(--tw-gradient-to-position))
    }

    .absr {
      --tw-gradient-to: #9089fc;
      --tw-gradient-stops: var(--tw-gradient-via-stops, var(--tw-gradient-position), var(--tw-gradient-from)var(--tw-gradient-from-position), var(--tw-gradient-to)var(--tw-gradient-to-position))
    }

    .abss {
      object-fit: cover
    }

    .abst {
      padding: .375rem
    }

    .absu {
      padding: .625rem
    }

    .absv {
      padding: 1.5rem
    }

    .absw {
      padding-inline: .75rem
    }

    .absx {
      padding-inline: .875rem
    }

    .absy {
      padding-inline: 1.5rem
    }

    .absz {
      padding-block: .25rem
    }

    .abta {
      padding-block: .5rem
    }

    .abtb {
      padding-block: .625rem
    }

    .abtc {
      padding-block: 1.5rem
    }

    .abtd {
      padding-block: 8rem
    }

    .abte {
      padding-top: 3.5rem
    }

    .abtf {
      text-align: center
    }

    .abtg {
      font-size: 3rem;
      line-height: var(--tw-leading, 1)
    }

    .abth {
      font-size: 1rem;
      line-height: 1.75rem
    }

    .abti {
      font-size: 1.125rem;
      line-height: var(--tw-leading, calc(1.75/1.125))
    }

    .abtj {
      font-size: .875rem;
      line-height: var(--tw-leading, calc(1.25/.875))
    }

    .abtk {
      font-size: .875rem;
      line-height: 1.5rem
    }

    .abtl {
      --tw-font-weight: 500;
      font-weight: 500
    }

    .abtm {
      --tw-font-weight: 600;
      font-weight: 600
    }

    .abtn {
      --tw-tracking: -.025em;
      letter-spacing: -.025em
    }

    .abto {
      text-wrap: balance
    }

    .abtp {
      text-wrap: pretty
    }

    .abtq {
      color: #99a1af
    }

    .abtr {
      color: #fff
    }

    .abts {
      opacity: .2
    }

    .abtt {
      --tw-shadow: 0 1px 2px 0 var(--tw-shadow-color, #0000000d);
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
    }

    .abtu {
      --tw-ring-shadow: var(--tw-ring-inset, )0 0 0 calc(1px + var(--tw-ring-offset-width))var(--tw-ring-color, currentcolor);
      box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow), var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow)
    }

    .abtv {
      --tw-ring-color: rgba(255, 255, 255, 0.1)
    }

    .abtw {
      --tw-blur: blur(64px);
      filter: var(--tw-blur, )var(--tw-brightness, )var(--tw-contrast, )var(--tw-grayscale, )var(--tw-hue-rotate, )var(--tw-invert, )var(--tw-saturate, )var(--tw-sepia, )var(--tw-drop-shadow, )
    }

    .abtx::backdrop {
      background-color: #0000
    }

    @media (hover:hover) {
      .abty:hover {
        background-color: #4a5565
      }

      .abtz:hover {
        background-color: #ed6bff
      }

      .abua:hover {
        --tw-ring-color: oklab(100% 0 5.96046e-8/.2)
      }
    }

    .abub:focus-visible {
      outline-style: var(--tw-outline-style);
      outline-width: 2px
    }

    .abuc:focus-visible {
      outline-offset: 2px
    }

    .abud:focus-visible {
      outline-color: #ed6bff
    }

    @media (min-width:40rem) {
      .abue {
        top: -20rem
      }

      .abuf {
        top: calc(100% - 30rem)
      }

      .abug {
        left: calc(50% + 36rem)
      }

      .abuh {
        left: calc(50% - 30rem)
      }

      .abui {
        margin-bottom: 2rem
      }

      .abuj {
        display: flex
      }

      .abuk {
        width: 72.1875rem
      }

      .abul {
        max-width: 24rem
      }

      .abum {
        justify-content: center
      }

      .abun {
        padding-block: 12rem
      }

      .abuo {
        font-size: 4.5rem;
        line-height: var(--tw-leading, 1)
      }

      .abup {
        font-size: 1.25rem;
      }
    }
  }
</style>
<div className="absn">
  <header className="abqn abqr abqu abrb">
    <nav aria-label="Global" className="abrl absb absc absv abux">
      <div className="abrl abuu"><a href="#" className="abrc abst"><span className="abqm">Your Company</span><img alt="Alt"
            src="http://localhost/mark-500.svg" className="abrs abru"></a>
      </div>
      <div className="abrl abut"><button type="button" className="abrd abro absb absd absm absu abtq"><span className="abqm">Open
            main menu</span><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5"
            stroke="currentColor" aria-hidden="true" data-slot="icon" className="abrq">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5">
            </path>
          </svg></button></div>
      <div className="abrn abus abuw"><a href="#" className="abtk abtm abtr">Product</a><a href="#"
          className="abtk abtm abtr">Features</a><a href="#" className="abtk abtm abtr">Marketplace</a><a href="#"
          className="abtk abtm abtr">Company</a></div>
      <div className="abrn abus abuu abuv"><a href="#" className="abtk abtm abtr">Log in <span aria-hidden="true">→</span></a>
      </div>
    </nav>
  </header>
  <div className="abqp abqz absi abte"><img alt="Alt"
      src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?ixlib=rb-4.0.3&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=2830&amp;q=80&amp;blend=111827&amp;sat=-100&amp;exp=15&amp;blend-mode=multiply"
      className="abqn abqq abra abrr abss">
    <div aria-hidden="true" className="abqn abqr abqt abra absa absi abtw abue clip-path-parent">
      <div className="abqp abqy abrp abrt abry abrz absp absq absr abts abuh abuk"
        style={{clipPath: "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)"}}>
      </div>
    </div>
    <div className="abrf abrx absy abux">
      <div className="abrf abrw abtd abun abuy">
        <div className="abrn abui abuj abum">
          <div className="abqp absk absw absz abtk abtq abtu abtv abua">Announcing our next round of funding. <a href="#"
              className="abtm abtr"><span aria-hidden="true" className="abqn abqq"></span>Read more <span
                aria-hidden="true">→</span></a></div>
        </div>
        <div className="abtf">
          <h1 className="abtg abtm abtn abto abtr abuo">Data to enrich your online business</h1>
          <p className="abri abti abtl abtp abtq abup">Anim aute id magna aliqua ad ad non deserunt sunt. Qui irure qui
            lorem cupidatat commodo. Elit sunt amet fugiat veniam occaecat.</p>
          <div className="abrj abrl absb absd absf"><a href="#"
              className="absm abso absx abtb abtj abtm abtr abtt abtz abub abuc abud">Get started</a><a href="#"
              className="abtk abtm abtr">Learn more <span aria-hidden="true">→</span></a></div>
        </div>
      </div>
    </div>
    <div aria-hidden="true" className="abqn abqr abqv abra absa absi abtw abuf clip-path-parent">
      <div className="abqp abqx abrp abrt abry absp absq absr abts abug abuk"
        style={{clipPath: "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)"}}>
      </div>
    </div>
  </div>
</div>
</div>
  );
}
