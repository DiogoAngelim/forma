export { default as Block1 } from './block-1';
export { default as Block2 } from './block-2';
export { default as Block3 } from './block-3';
export { default as Block4 } from './block-4';
export { default as Block5 } from './block-5';
export { default as Block6 } from './block-6';
export { default as Block7 } from './block-7';