import React from 'react';

export default function Block1(props) {
  return (
    <div>
<header className="wp-block-template-part">

    </header>
</div>
  );
}
