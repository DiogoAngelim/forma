export { default as Block1 } from './block-1';
export { default as Block2 } from './block-2';