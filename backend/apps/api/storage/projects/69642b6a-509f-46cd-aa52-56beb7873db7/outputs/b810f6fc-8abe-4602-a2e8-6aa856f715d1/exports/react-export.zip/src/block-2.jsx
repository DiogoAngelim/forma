import React from 'react';

export default function Block2(props) {
  return (
    <div>
<main className="wp-block-group" id="wp--skip-link--target">
      <div className="entry-content wp-block-post-content">
        <div className="wp-block-wp-with-angled-image-on-right">
          <div>
            <div className="relative bg-white overflow-hidden">
              <div className="max-w-7xl mx-auto">
                <div className="relative z-10 pb-8 bg-white sm:pb-16 md:pb-20 lg:max-w-2xl lg:w-full lg:pb-28 xl:pb-32"><svg
                    className="hidden lg:block absolute right-0 inset-y-0 h-full w-48 text-white transform translate-x-1/2"
                    fill="currentColor" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                    <polygon points="50,0 100,0 50,100 0,100"></polygon>
                  </svg>
                  <div>
                  </div>
                  <main className="mt-0 pt-7 mx-auto max-w-7xl pb-4 sm:mt-12 sm:px-6 md:mt-16 lg:mt-0 lg:px-8 xl:mt-0">
                    <div className="sm:text-center lg:text-left">
                      <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 sm:text-5xl md:text-6xl"><span
                          className="block xl:inline"><strong>Effortless WordPress Integration </strong></span><span
                          className="block text-indigo-600 xl:inline">in <strong>no time </strong></span></h1>
                      <p
                        className="mt-3 text-base text-gray-500 sm:mt-5 sm:text-lg sm:max-w-xl sm:mx-auto md:mt-5 md:text-xl lg:mx-0">
                        Tired of manually creating WordPress blocks from HTML? Save time and effort with our powerful
                        tool that converts your HTML directly into fully customizable Gutenberg blocks. Whether you’re a
                        developer or content creator, streamline your workflow and focus on what matters most.</p>
                      <div className="mt-5 sm:mt-8 sm:flex sm:justify-center lg:justify-start">
                        <a href="https://www.html-to-gutenberg.io/app/" target="_blank" className="rounded-md shadow"
                          style={{textDecoration: "none"}}> <span
                            className="w-full flex items-center justify-center no-underline px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 md:py-4 md:text-lg md:px-10">
                            Get started – It’s free</span></a>
                        <a href="https://youtu.be/-IUb8e8gLDk" target="_blank" className="no-underline mt-3 sm:mt-0 sm:ml-3"
                          style={{textDecoration: "none"}}> <span style={{textDecoration: "none"}}
                            className="no-underline flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-indigo-100 hover:bg-indigo-200 md:py-4 md:text-lg md:px-10">Watch
                            Demo</span></a>
                      </div>
                    </div>
                  </main>
                </div>
              </div>
              <div className="lg:absolute lg:inset-y-0 lg:right-0 lg:w-1/2"><img decoding="async"
                  className="h-56 w-full object-cover sm:h-72 md:h-96 lg:w-full lg:h-full"
                  src="https://www.danielmcclure.com/wp-content/uploads/gutenberg.png" alt=""></div>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-offset-2x2-grid">
          <div>
            <div className="bg-gray-50 overflow-hidden">
              <div className="relative max-w-7xl mx-auto pt-[240px] px-4 sm:px-6 lg:px-8"><svg
                  className="absolute top-0 left-full transform -translate-x-1/2 -translate-y-3/4 lg:left-auto lg:right-full lg:translate-x-2/3 lg:translate-y-1/4"
                  width="404" height="784" fill="none" viewBox="0 0 404 784" aria-hidden="true">
                  <defs>
                    <pattern id="8b1b5f72-e944-4457-af67-0c6d15a99f38" x="0" y="0" width="20" height="20"
                      patternUnits="userSpaceOnUse">
                      <rect x="0" y="0" width="4" height="4" classname="text-gray-200" fill="lightgray"></rect>
                    </pattern>
                  </defs>
                  <rect width="404" height="784" fill="url(#8b1b5f72-e944-4457-af67-0c6d15a99f38)"></rect>
                </svg>
                <div className="relative lg:grid lg:grid-cols-3 lg:gap-x-8">
                  <div className="lg:col-span-1">
                    <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 sm:text-4xl">A better way to edit
                      content.</h2>
                  </div>
                  <dl
                    className="mt-10 space-y-10 sm:space-y-0 sm:grid sm:grid-cols-2 sm:gap-x-8 sm:gap-y-10 lg:mt-0 lg:col-span-2">
                    <div>
                      <dt>
                        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white"><svg
                            className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" aria-hidden="true">
                            <path className="size-6" strokeLinecap="round" strokeLinejoin="round"
                              d="M7.5 21 3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5" />
                          </svg></div>
                        <p className="mt-5 text-lg leading-6 font-medium text-gray-900">Instant Conversions</p>
                      </dt>
                      <dd className="mt-2 text-base text-gray-500">With instant conversions, transform your HTML into fully
                        functional Gutenberg blocks in seconds.</dd>
                    </div>
                    <div>
                      <dt>
                        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white"><svg
                            className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round"
                              d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                          </svg></div>
                        <p className="mt-5 text-lg leading-6 font-medium text-gray-900">Time-Saving Automation</p>
                      </dt>
                      <dd className="mt-2 text-base text-gray-500">Boost your efficiency by eliminating the need for manual
                        coding and repetitive
                        tasks. </dd>
                    </div>
                    <div>
                      <dt>
                        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white"><svg
                            className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2"
                              d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                          </svg></div>
                        <p className="mt-5 text-lg leading-6 font-medium text-gray-900">Seamless WordPress Integration</p>
                      </dt>
                      <dd className="mt-2 text-base text-gray-500">Ensure that your converted Gutenberg blocks work
                        flawlessly with any WordPress theme. </dd>
                    </div>
                    <div>
                      <dt>
                        <div className="flex items-center justify-center h-12 w-12 rounded-md bg-indigo-500 text-white"><svg
                            className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" aria-hidden="true">
                            <path strokeLinecap="round" strokeLinejoin="round"
                              d="M9.53 16.122a3 3 0 0 0-5.78 1.128 2.25 2.25 0 0 1-2.4 2.245 4.5 4.5 0 0 0 8.4-2.245c0-.399-.078-.78-.22-1.128Zm0 0a15.998 15.998 0 0 0 3.388-1.62m-5.043-.025a15.994 15.994 0 0 1 1.622-3.395m3.42 3.42a15.995 15.995 0 0 0 4.764-4.648l3.876-5.814a1.151 1.151 0 0 0-1.597-1.597L14.146 6.32a15.996 15.996 0 0 0-4.649 4.763m3.42 3.42a6.776 6.776 0 0 0-3.42-3.42" />
                          </svg></div>
                        <p className="mt-5 text-lg leading-6 font-medium text-gray-900">Customizable Blocks</p>
                      </dt>
                      <dd className="mt-2 text-base text-gray-500">Easily modify text, images, links, and icons
                        directly in the Gutenberg editor. </dd>
                    </div>
                  </dl>
                </div>
              </div>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-with-background-image-and-overlapping-cards">
          <div>
            <div className="bg-white">
              <div className="relative pb-32 bg-gray-800">
                <div className="absolute inset-0"><img decoding="async" className="w-full h-full object-cover"
                    src="img/photo-1525130413817-d45c1d127c42.jpeg" alt="">
                  <div className="absolute inset-0 bg-gray-800 mix-blend-multiply" aria-hidden="true"></div>
                </div>
                <div className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
                  <h1 className="text-4xl font-extrabold tracking-tight text-white md:text-5xl lg:text-6xl">How It Works
                  </h1>
                  <p className="mt-6 max-w-3xl text-xl text-gray-300">Provide your HTML, and our tool instantly converts it
                    into fully editable Gutenberg blocks. Upload as a WordPress plugin and there you go.</p>
                </div>
              </div>
              <section className="-mt-32 max-w-7xl mx-auto relative z-10 pb-32 px-4 sm:px-6 lg:px-8"
                aria-labelledby="contact-heading">
                <h2 className="sr-only" id="contact-heading">Contact us</h2>
                <div className="grid grid-cols-1 gap-y-20 lg:grid-cols-3 lg:gap-y-0 lg:gap-x-8">
                  <div className="flex flex-col bg-white rounded-2xl shadow-xl">
                    <div className="flex-1 relative pt-16 px-6 pb-8 md:px-8">
                      <div
                        className="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
                        <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none"
                          viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                          <path strokeLinecap="round" strokeLinejoin="round"
                            d="M14.25 9.75 16.5 12l-2.25 2.25m-4.5 0L7.5 12l2.25-2.25M6 20.25h12A2.25 2.25 0 0 0 20.25 18V6A2.25 2.25 0 0 0 18 3.75H6A2.25 2.25 0 0 0 3.75 6v12A2.25 2.25 0 0 0 6 20.25Z" />
                        </svg>
                      </div>
                      <h3 className="text-xl font-medium text-gray-900">Enter Your HTML block string to the API</h3>
                      <p className="mt-4 text-base text-gray-500">Simply enter a valid HTML block string, and our tool will
                        automatically recognize the content structure. No need for extra setup or configurations.</p>
                    </div>
                    <a href="https://youtu.be/-IUb8e8gLDk" target="_blank"
                      className="no-underline p-6 bg-gray-50 rounded-bl-2xl rounded-br-2xl md:px-8"> <span
                        className="no-underline text-base font-medium text-indigo-700 hover:text-indigo-600"><br/>Watch the
                        demo<span aria-hidden="true"> →</span></span></a>
                  </div>
                  <div className="flex flex-col bg-white rounded-2xl shadow-xl">
                    <div className="flex-1 relative pt-16 px-6 pb-8 md:px-8">
                      <div
                        className="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
                        <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none"
                          viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                          <path strokeLinecap="round" strokeLinejoin="round"
                            d="M3.75 9.776c.112-.017.227-.026.344-.026h15.812c.117 0 .232.009.344.026m-16.5 0a2.25 2.25 0 0 0-1.883 2.542l.857 6a2.25 2.25 0 0 0 2.227 1.932H19.05a2.25 2.25 0 0 0 2.227-1.932l.857-6a2.25 2.25 0 0 0-1.883-2.542m-16.5 0V6A2.25 2.25 0 0 1 6 3.75h3.879a1.5 1.5 0 0 1 1.06.44l2.122 2.12a1.5 1.5 0 0 0 1.06.44H18A2.25 2.25 0 0 1 20.25 9v.776" />
                        </svg>
                      </div>
                      <h3 className="text-xl font-medium text-gray-900">Our tool converts and generate the dependencies for
                        you</h3>
                      <p className="mt-4 text-base text-gray-500">Within seconds, your HTML is transformed into a few
                        project files, preserving layout and design. The block is ready for building right next.</p>
                    </div>
                    <a href="https://youtu.be/-IUb8e8gLDk" target="_blank"
                      className="no-underline p-6 bg-gray-50 rounded-bl-2xl rounded-br-2xl md:px-8"> <span
                        className="no-underline text-base font-medium text-indigo-700 hover:text-indigo-600">Watch the
                        demo<span aria-hidden="true"> →</span></span></a>
                  </div>
                  <div className="flex flex-col bg-white rounded-2xl shadow-xl">
                    <div className="flex-1 relative pt-16 px-6 pb-8 md:px-8">
                      <div
                        className="absolute top-0 p-5 inline-block bg-indigo-600 rounded-xl shadow-lg transform -translate-y-1/2">
                        <svg className="h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none"
                          viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                          <path strokeLinecap="round" strokeLinejoin="round"
                            d="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 0 1-.657.643 48.39 48.39 0 0 1-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 0 1-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 0 0-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 0 1-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 0 0 .657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 0 1-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 0 0 5.427-.63 48.05 48.05 0 0 0 .582-4.717.532.532 0 0 0-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 0 0 .658-.663 48.422 48.422 0 0 0-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 0 1-.61-.58v0Z" />
                        </svg>
                      </div>
                      <h3 className="text-xl font-medium text-gray-900">Build valid code, compress, upload as a plugin, and
                        that’s it.</h3>
                      <p className="mt-4 text-base text-gray-500">Generate valid, optimized code from the source
                        automatically. Compress the package, and upload as a WordPress Plugin. Activate it it, and
                        you’re done.</p>
                    </div>
                    <a href="https://youtu.be/-IUb8e8gLDk" target="_blank"
                      className="no-underline p-6 bg-gray-50 rounded-bl-2xl rounded-br-2xl md:px-8"> <span
                        className="no-underline text-base font-medium text-indigo-700 hover:text-indigo-600">Watch the
                        demo<span aria-hidden="true"> →</span></span></a>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-simple-on-brand">
          <div>
            <div className="bg-indigo-800">
              <div className="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8 lg:py-20">
                <div className="max-w-4xl mx-auto text-center">
                  <h2 className="text-3xl font-extrabold text-white sm:text-4xl">Trusted by developers from over 80
                    companies</h2>
                  <p className="mt-3 text-xl text-indigo-200 sm:mt-4">Developers from over 80 companies rely on our tool to
                    streamline their workflow and enhance productivity. From startups to established enterprises,
                    professionals trust our solution for fast, reliable HTML-to-Gutenberg conversion. Join the growing
                    community and experience the difference today!</p>
                </div>
                <dl className="mt-10 text-center sm:max-w-3xl sm:mx-auto sm:grid sm:grid-cols-3 sm:gap-8">
                  <div className="flex flex-col">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-indigo-200">Accuracy</dt>
                    <dd className="order-1 text-5xl font-extrabold text-white">99%</dd>
                  </div>
                  <div className="flex flex-col mt-10 sm:mt-0">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-indigo-200">Monthly downloads</dt>
                    <dd className="order-1 text-5xl font-extrabold text-white">1K+</dd>
                  </div>
                  <div className="flex flex-col mt-10 sm:mt-0">
                    <dt className="order-2 mt-2 text-lg leading-6 font-medium text-indigo-200">Blocks built</dt>
                    <dd className="order-1 text-5xl font-extrabold text-white">2k+</dd>
                  </div>
                </dl>
              </div>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-with-overlapping-image">
          <div>
            <div className="bg-white">
              <div className="pb-16 bg-indigo-600 lg:pb-0 lg:z-10 lg:relative">
                <div className="lg:mx-auto lg:max-w-7xl lg:px-8 lg:grid lg:grid-cols-3 lg:gap-8">
                  <div className="relative lg:-my-8">
                    <div aria-hidden="true" className="bg-indigo-600 inset-x-0 top-0 h-1/2 bg-white lg:hidden"></div>
                    <div className="mx-auto max-w-md px-4 sm:max-w-3xl sm:px-6 lg:p-0 lg:h-full">
                      <div
                        className="aspect-w-10 aspect-h-6 rounded-xl shadow-xl overflow-hidden sm:aspect-w-16 sm:aspect-h-7 lg:aspect-none lg:h-full">
                        <img decoding="async" src="img/photo-1520333789090-1afc82db536a.jpeg" alt=""
                          className="relative object-cover lg:h-full lg:w-full">
                      </div>
                    </div>
                  </div>
                  <div className="mt-12 lg:m-0 lg:col-span-2 lg:pl-8">
                    <div className="mx-auto max-w-md px-4 sm:max-w-2xl sm:px-6 lg:px-0 lg:py-20 lg:max-w-none">
                      <blockquote>
                        <div><svg className="h-12 w-12 text-white opacity-25" fill="currentColor" viewBox="0 0 32 32"
                            aria-hidden="true">
                            <path
                              d="M9.352 4C4.456 7.456 1 13.12 1 19.36c0 5.088 3.072 8.064 6.624 8.064 3.36 0 5.856-2.688 5.856-5.856 0-3.168-2.208-5.472-5.088-5.472-.576 0-1.344.096-1.536.192.48-3.264 3.552-7.104 6.624-9.024L9.352 4zm16.512 0c-4.8 3.456-8.256 9.12-8.256 15.36 0 5.088 3.072 8.064 6.624 8.064 3.264 0 5.856-2.688 5.856-5.856 0-3.168-2.304-5.472-5.184-5.472-.576 0-1.248.096-1.44.192.48-3.264 3.456-7.104 6.528-9.024L25.864 4z">
                            </path>
                          </svg>
                          <p className="mt-6 text-2xl font-medium text-white">This tool has saved me hours of work! The
                            blocks are perfect and fully editable. I can’t imagine going back to manual conversions.</p>
                        </div>
                        <footer className="mt-6">
                          <p className="text-base font-medium text-white">Judith Black</p>
                          <p className="text-base font-medium text-indigo-100">CEO at PureInsights</p>
                        </footer>
                      </blockquote>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-simple-justified-on-light-brand">
          <div>
            <div className="bg-indigo-50">
              <div
                className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:py-24 lg:px-8 lg:flex lg:items-center lg:justify-between">
                <h2 className="text-3xl font-extrabold tracking-tight text-gray-900 md:text-4xl"><span className="block">Ready
                    to convert your HTML into WordPress blocks?</span><span className="block text-indigo-600">Start today.
                    It’s free.</span></h2>
                <div className="mt-8 flex lg:mt-0 lg:flex-shrink-0">
                  <a href="https://www.html-to-gutenberg.io/app/" target="_blank" style={{textDecoration: "none"}}
                    className="inline-flex rounded-md shadow"> <span
                      className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                      Get started </span></a>
                </div>
              </div>
            </div>
          </div>
        </div>



        <div className="wp-block-wp-social-links-only">
          <div>
            <footer className="bg-white">
              <div className="max-w-7xl mx-auto py-[20px] px-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
                <div className="flex justify-center space-x-6 md:order-2"> <span
                    className="text-gray-400 hover:text-gray-600"><span className="sr-only">Facebook</span><svg className="h-6 w-6"
                      fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"></svg></span> <span
                    className="text-gray-400 hover:text-gray-600"><span className="sr-only">Instagram</span><svg className="h-6 w-6"
                      fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"></svg></span> <span
                    className="text-gray-400 hover:text-gray-600"><span className="sr-only">Twitter</span><svg className="h-6 w-6"
                      fill="currentColor" viewBox="0 0 24 24" aria-hidden="true"></svg></span> <a
                    href="https://github.com/diogoangelim/html-to-gutenberg/" target="_blank"
                    className="text-gray-400 hover:text-gray-600"><span className="sr-only">GitHub</span><svg
                      className="h-6 w-6 hover:text-gray-600" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fill-rule="evenodd"
                        d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"
                        clip-rule="evenodd"></path>
                    </svg></a> <a href="https://www.npmjs.com/package/html-to-gutenberg/" target="_blank"
                    className="text-gray-400 hover:text-gray-600"><span className="sr-only">NPM</span><svg className="h-6 w-6"
                      fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <g xmlns="http://www.w3.org/2000/svg">
                        <path fill="none" d="M0 0H24V24H0z"></path>
                        <path
                          d="M20 3c.552 0 1 .448 1 1v16c0 .552-.448 1-1 1H4c-.552 0-1-.448-1-1V4c0-.552.448-1 1-1h16zm-3 4H7v10h5V9.5h2.5V17H17V7z"
                          fill=""></path>
                      </g>
                    </svg></a></div>
                <div className="mt-8 md:mt-0 md:order-1">
                  <p className="text-center text-base text-gray-400">© 2024 Diogo Angelim. All rights reserved.</p>
                </div>
              </div>
            </footer>
          </div>
        </div>
      </div>
    </main>
</div>
  );
}
